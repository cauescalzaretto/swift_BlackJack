//
//  Player.swift
//  Project 52 Cards
//
//  Created by Caue Scalzaretto on 09/03/16.
//  Copyright © 2016 Caue Scalzaretto. All rights reserved.
//

import Foundation

class Player
{
    // MARK: PROPERTIES
    enum stateOfPlayer
    {
        case Waiting
        case Stopping
        case Betting
        case Playing
        case Losing
        case Winning
        
        func description() -> String
        {
            switch self
            {
            case .Losing:
                return "Losing"
            case .Playing:
                return "Playing"
            case .Stopping:
                return "Stopping"
            case .Waiting:
                return "Waiting"
            case .Winning:
                return "Winning"
            case .Betting:
                return "Betting"
                
            }
        }
    }
    
    private var namePlayer: String
    private var gamingChips: Int
    private var cards: [Card] = []
    private var state: stateOfPlayer

    // MARK: INIT
    
    init(NameOfPlayer umName: String, GamingChipsOfPlayer umGamingChips: Int)
    {
        self.namePlayer = umName
        self.gamingChips = umGamingChips
        self.state = stateOfPlayer.Waiting
    }
    
    // MARK: METTHODS

    func addCardToPlayer(ACard umaCard: Card)
    {
        cards.append(umaCard)
    }
    
    func removeACardOfPlayer() -> Card?
    {
        return cards.removeAtIndex(0)
    }

    func removeACardOfPlayer(IndexCard umIndex: Int) -> Card?
    {
       return cards.removeAtIndex(umIndex)
    }
    
    func addGamingChips(QuantityGamingChips umasChips: Int)
    {
        gamingChips += umasChips
    }

    func removeGamingChips(QuantityGamingChips umasChips: Int)
    {
        gamingChips -= umasChips
    }
    
    func whereAmountGamingChips() -> Int
    {
        return self.gamingChips
    }
    
    func displayCardsOfPlayer() -> [Card]
    {
        return cards
    }
    
    func nameOfPlayer() -> String
    {
        return self.namePlayer
    }
    
    func changeStateOfPlayer(NewStateOfPlayer umState: stateOfPlayer)
    {
        self.state = umState
    }
    
    func displayStateOfPlayer() -> stateOfPlayer
    {
        return self.state
    }
    
    func newHand()
    {
        self.cards = []
        self.changeStateOfPlayer(NewStateOfPlayer: stateOfPlayer.Waiting)
    }
    
    
    
}