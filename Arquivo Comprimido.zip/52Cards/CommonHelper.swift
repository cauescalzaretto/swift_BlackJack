//
//  CommonHelper.swift
//  blackJack
//
//  Created by Swift on 07/03/16.
//  Copyright © 2016 Quaddro. All rights reserved.
//

import Foundation


//==========================================================================
// MARK: FUNCTIONS
//==========================================================================

func entradaDeDados() -> NSString
{
    // Objeto que representará nossa entrada via teclado
    let preparacaoTeclado = NSFileHandle.fileHandleWithStandardInput()
    // Aguarda o usuario digitar e teclar <ENTER>
    let dadoEntrada = preparacaoTeclado.availableData
    // Retorna a informação digitada
    return NSString(data: dadoEntrada, encoding: NSUTF8StringEncoding)!
}

func selecionaNumeroRandomico( ondeOLimiteSerá numeroLimite: Int) -> Int
{
    let numeroEscolhido = arc4random() % UInt32(numeroLimite)
    
    return numeroEscolhido.hashValue
}

func apresentaItensDeUmaArrayDeString(arrayDeString umaArray: [String]) -> String
{
    var stringDeRetorno = ""
    
    for itemArray in umaArray
    {
        stringDeRetorno += itemArray + "\n"
    }
    
    return stringDeRetorno
}


//==========================================================================
// MARK: EXTENSIONS
//==========================================================================

extension MutableCollectionType where Index == Int {
    /// Shuffle the elements of `self` in-place.
    mutating func shuffleInPlace() {
        // empty and single-element collections don't shuffle
        if count < 2 { return }
        
        for i in 0..<count - 1 {
            let j = Int(arc4random_uniform(UInt32(count - i))) + i
            guard i != j else { continue }
            swap(&self[i], &self[j])
        }
    }
}

extension String {
    
    /// Converte a string para um Double?
    func toDouble() -> Double? {
        return NSNumberFormatter().numberFromString(self as String)?.doubleValue
    }
    
    /// Converte a string para um Int?
    func toInt() -> Int?{
//        let numero = (self as NSString).integerValue
//        return numero
        return NSNumberFormatter().numberFromString(self as String)!.integerValue
    }
    
    
    /// Converte a string para um Float?
    func toFloat() -> Float?{
//        let numero = (self as NSString).Float?
//        return numero
        return NSNumberFormatter().numberFromString(self as String)?.floatValue
    }
    
    /// Retorna true se a string possuir um dos caracteres de matchCharacters
    func containsCharactersIn(matchCharacters: String) -> Bool {
        let characterSet = NSCharacterSet(charactersInString: matchCharacters)
        return self.rangeOfCharacterFromSet(characterSet) != nil
    }

    /// Retorna true se a string possuir somente caracteres de matchCharacters
    func containsOnlyCharactersIn(matchCharacters: String) -> Bool {
        let disallowedCharacterSet = NSCharacterSet(charactersInString: matchCharacters).invertedSet
        return self.rangeOfCharacterFromSet(disallowedCharacterSet) == nil
    }
    
    /// Retorna true se a string não tiver nenhum caracteres de matchCharacters
    func doesNotContainCharactersIn(matchCharacters: String) -> Bool {
        let characterSet = NSCharacterSet(charactersInString: matchCharacters)
        return self.rangeOfCharacterFromSet(characterSet) == nil
    }
    
    /// Retorna true se a string representa um valor numérico
    /// Este método utiliza as configurações locais para determinar, através do separador decimal
    func isNumeric() -> Bool
    {
        let scanner = NSScanner(string: self)
        
        // A newly-created scanner has no locale by default.
        // We'll set our scanner's locale to the user's locale
        // so that it recognizes the decimal separator that
        // the user expects (for example, in North America,
        // "." is the decimal separator, while in many parts
        // of Europe, "," is used).
        scanner.locale = NSLocale.currentLocale()
        
        return scanner.scanDecimal(nil) && scanner.atEnd
    }
    
    
    
}

