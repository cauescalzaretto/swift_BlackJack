//
//  IAPlayerBlackJack.swift
//  52Cards
//
//  Created by Caue Scalzaretto on 26/03/16.
//  Copyright © 2016 Caue Scalzaretto. All rights reserved.
//

import Foundation


//===========================================
// ENUM BEHAVIOR
//===========================================

enum levelBehavior
{
    case Conservative, Moderate, Aggressive, Dealer
    
    func valueLimit() -> Int
    {
        switch self
        {
        case .Conservative:
            return 16
        case .Moderate:
            return 18
        case .Aggressive:
            return 20
        case .Dealer:
            return 17
        }
    }
    
}

//===========================================
// CLASS IA PLAYER BLACK JACK
//===========================================

class IAPlayerBlackJack: PlayerBlackJack {
    
    // MARK: PROPERTIES
    
    private var behavior: levelBehavior
    

    // MARK: INIT
    
    init(APlayer umPlayer: Player, Behavior umBehavior: levelBehavior) {
        
        self.behavior = umBehavior
        
        super.init(APlayer: umPlayer)
        self.getViewPlayer().hiddenButtonOption1(IsHidden: true)
        self.getViewPlayer().hiddenButtonOption2(IsHidden: true)
        
        if self.behavior == .Dealer
        {
            self.getViewPlayer().setTextLabelUp(TextOfLabel: "")
            self.getViewPlayer().setTextLabelBottom(TextOfLabel: "Score: \(super.displayScore())")
        }
        
    }
    
    
    // MARK: METHODS
    
    func changeBehavior(NewBehavior umBehavior: levelBehavior)
    {
        self.behavior = umBehavior
    }
    
    func displayBehavior() -> levelBehavior
    {
        return self.behavior
    }
    
    //Modifica o status do jogador
    override func changeStateOfPlayer(NewStateOfPlayer umState: stateOfPlayer)
    {
        super.changeStateOfPlayer(NewStateOfPlayer: umState)
        self.getViewPlayer().hiddenButtonOption1(IsHidden: true)
        self.getViewPlayer().hiddenButtonOption2(IsHidden: true)
        
        //Verifica o status do jogador para modificar o uiViewPlayer
        switch(self.displayStateOfPlayer())
        {
            
        case .Betting:
            self.increaseBet(ValueBet: self.increaseBetIAPlayer())
            break
            
        case .Playing:
            
            var decision = decisionDrawCard()
            
            while(decision)
            {
                executeDecision(TheDecision: decision)
                decision = decisionDrawCard()
            }
            
            super.verifyScore(StatePattern: Player.stateOfPlayer.Stopping)
            
            break
            
        default:
            self.getViewPlayer().setTextLabelBottom(TextOfLabel: "Score: \(super.displayScore()) - \(self.displayStateOfPlayer().description())")
            self.getViewPlayer().hiddenButtonOption1(IsHidden: true)
            self.getViewPlayer().hiddenButtonOption2(IsHidden: true)
            break
        }
        
    }
    
    private func increaseBetIAPlayer() -> Int
    {
        switch self.behavior
        {
        case .Conservative:
            return 10
        case .Moderate:
            return 20
        case .Aggressive:
            return 30
        case .Dealer:
            return 0
        }
    }
    
    private func decisionDrawCard() -> Bool
    {
        if self.displayScore() < self.behavior.valueLimit()
        {
            //Hit
            return true
        }
        else
        {
            // Stand
            return false
        }
    }
    
    private func executeDecision(TheDecision aDecision: Bool)
    {
        if aDecision
        {
            // Hit
            self.addCardToPlayer(ACard: meuBaralho.drawCard(Hidden: false))
            self.getViewPlayer().setTextLabelBottom(TextOfLabel: "Score: \(super.displayScore()) - Bet: \(super.returnBetPlayer())")

        }
        else
        {
            // Stand
            self.changeStateOfPlayer(NewStateOfPlayer: stateOfPlayer.Stopping)
        }
        self.getViewPlayer().displayCardsPlayer(CarsOfPlayer: self.displayCardsOfPlayer())

    }
    
    
}