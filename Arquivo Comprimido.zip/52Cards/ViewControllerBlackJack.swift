//
//  ViewController.swift
//  52Cards
//
//  Created by Caue Scalzaretto on 13/03/16.
//  Copyright © 2016 Caue Scalzaretto. All rights reserved.
//

import UIKit


// GLOBAL
let meuBaralho = Deck()



class ViewControllerBlackJack: UIViewController {

    //===========================================================
    // MARK: PROPERTIES
    //===========================================================
    
    var arrayPlayers:[PlayerBlackJack] = []

    var dealer: IAPlayerBlackJack!
    
    //===========================================================
    // MARK: OUTLETS
    //===========================================================

    @IBOutlet weak var yourState: UILabel!
    
    @IBOutlet weak var start: UIButton!
    
    //===========================================================
    // MARK: ACTIONS
    //===========================================================

    @IBAction func restart()
    {
        if (self.start.tag == 0)
        {
            self.start.tag = 1
            self.start.setTitle("RESTART", forState: UIControlState.Normal)

            //Inicia a rodada criando os jogadores
            createPlayers()
            createDealer()
            
            beginBlackJack()
            
            beginRound()
            
        }
        else
        {
            beginBlackJack()
            
            for (var contador = 0; contador < arrayPlayers.count; contador++)
            {
                arrayPlayers[contador].newHand()
            }
            
            beginRound()
        }
    }
    
    //===========================================================
    // MARK: SUPERVIEW METHODS
    //===========================================================
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    //===========================================================
    // MARK: ENGINE GAME METHODS
    //===========================================================
    
    func beginBlackJack()
    {
        // Cria o baralho
        meuBaralho.createDeck()
        
        // Embaralha o baralho
        meuBaralho.shuffleCardsInDeck()
        
    }
    
    
    func beginRound()
    {
        //Atualiza o status dos jogadores para Betting
        modifyStateOfPlayer(ThePlayers: arrayPlayers, NewStateOfPlayer: PlayerBlackJack.stateOfPlayer.Betting)
        
        // Começa a rodada com as apostas
        takeBetOfPlayers(ThePlayers: arrayPlayers)
        
        //Dealer distribui as primeiras cartas
        drawCardToPlayers(ThePlayers: arrayPlayers)
        
        //Dealer pega a sua primeira carta (escondida)
        drawCardToDealer(IsHiddenCard: true)
        
        //=========================
        //TEMPORIZA uns 3 segundos
        //=========================
        
        //Dealer distribui as segundas cartas
        drawCardToPlayers(ThePlayers: arrayPlayers)
        
        //Dealer pega a sua segunda carta
        drawCardToDealer(IsHiddenCard: false)
        
        //=========================
        //TEMPORIZA uns 3 segundos
        //=========================
        
        // Verifica se deve oferecer Seguro para os jogadores
        //-------------------------------
        // TODO
        //-------------------------------

        //Atualiza o status dos jogadores para Playing
        modifyStateOfPlayer(ThePlayers: arrayPlayers, NewStateOfPlayer: PlayerBlackJack.stateOfPlayer.Playing)

        //Dealer joga por último
        
    }

    //===========================================================
    // MARK: DISPLAY GAME METHODS
    //===========================================================
    
    func displayCardsImageView(APlayerBlackJack umPlayer: PlayerBlackJack)
    {
        umPlayer.displayCardsViewPlayer()
    }
    
    
    //===========================================================
    // MARK: AUXILIAR GAME METHODS
    //===========================================================
    
    func drawCardToPlayers(ThePlayers umPlayers: [PlayerBlackJack])
    {
        for (var contador = 0; contador <= umPlayers.count - 1; contador++)
        {
            //Adiciona a carta para o jogador
            umPlayers[contador].addCardToPlayer(ACard: meuBaralho.drawCard(Hidden: false))
            
            //Apresenta a carta do jogador
            displayCardsImageView(APlayerBlackJack: umPlayers[contador])

        }
    }
    func drawCardToDealer(IsHiddenCard aHidden: Bool)
    {
        dealer.addCardToPlayer(ACard: meuBaralho.drawCard(Hidden: aHidden))
    
        displayCardsImageView(APlayerBlackJack: dealer)
    }
    
    func takeBetOfPlayers(ThePlayers umPlayers: [PlayerBlackJack])
    {
        for (var contador = 0; contador <= umPlayers.count - 1; contador++)
        {
            
            sleep(1)
            
//            while(umPlayers[contador].displayStateOfPlayer()==Player.stateOfPlayer.Betting){
//            
//            print("oi")
//            }
            
            
        }
    }
    
    
    func createPlayers()
    {

        //Inicializa a array novamente
        arrayPlayers.removeAll()
        
        // Inicia inserindo o jogador do aparelho sempre
        arrayPlayers.append(PlayerBlackJack(APlayer: Player(NameOfPlayer: "Caue", GamingChipsOfPlayer: 100)))
        arrayPlayers[0].setFrameViewPlayer(Frame: CGRectMake(199, 188, 83, 132))
        self.view.addSubview(arrayPlayers[0].getViewPlayer())
        
        for (var contador = 1; contador <= 4; contador++)
        {
            //Cria os bots neste momento, definindo a dificuladade (behavior)
            arrayPlayers.append(IAPlayerBlackJack(APlayer: Player(NameOfPlayer: "Bot\(contador)", GamingChipsOfPlayer: 100), Behavior: levelBehavior.Conservative))
            arrayPlayers[contador].setFrameViewPlayer(Frame: CGRectMake(CGFloat(17 + (91 * (contador >= 3 ? contador : contador - 1))), 188, 101, 132))
            self.view.addSubview(arrayPlayers[contador].getViewPlayer())
        }
        
    }
    
    func createDealer()
    {
        dealer = IAPlayerBlackJack(APlayer: Player(NameOfPlayer: "Dealer", GamingChipsOfPlayer: 100), Behavior: levelBehavior.Dealer)
        dealer.setFrameViewPlayer(Frame: CGRectMake(198, 78, 101, 132))
        self.view.addSubview(dealer.getViewPlayer())
        
    }
    
    func modifyStateOfPlayer(ThePlayers aPlayers: [PlayerBlackJack], NewStateOfPlayer aState: PlayerBlackJack.stateOfPlayer)
    {
        for (var contador = 0; contador <= aPlayers.count - 1; contador++)
        {
            //Atualiza o status do jogador
            aPlayers[contador].changeStateOfPlayer(NewStateOfPlayer: aState)
        }
    }
    
}

