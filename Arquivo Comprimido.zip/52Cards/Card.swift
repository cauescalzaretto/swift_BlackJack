//
//  Card.swift
//  Project 52 Cards
//
//  Created by Caue Scalzaretto on 09/03/16.
//  Copyright © 2016 Caue Scalzaretto. All rights reserved.
//

import Foundation
import UIKit

// MARK: ENUMERATORS

enum Suit: String
{
    case Spades = "♠", Hearts = "♡", Diamonds = "♢", Clubs = "♣"

    func description() -> String
    {
        switch self
        {
        case .Spades:
            return "Spades"
        case .Hearts:
            return "Hearts"
        case .Diamonds:
            return "Diamonds"
        case .Clubs:
            return "Clubs"
        }
    }
}

enum Rank: Int
{
    case Ace = 1, Two,Three, Four, Five, Six, Seven, Eight, Nine, Ten
    case Jack, Queen, King
    
    func description() -> String
    {
        switch self
        {
        case .King:
            return "King"
        case .Queen:
            return "Queen"
        case .Jack:
            return "Jack"
        case .Ace:
            return "Ace"
        case .Two:
            return "Two"
        case .Three:
            return "Three"
        case .Four:
            return "Four"
        case .Five:
            return "Five"
        case .Six:
            return "Six"
        case .Seven:
            return "Seven"
        case .Eight:
            return "Eight"
        case .Nine:
            return "Nine"
        case .Ten:
            return "Ten"
        }
    }
    
    func values() -> Int
    {
        switch self
        {
        case .Ace:
            return 1
        case .King, .Queen, .Jack:
            return 10
        default:
            return self.rawValue
        }
    }
    
}


// MARK: STRUCTURES

struct Values
{
    let firstValue: Int
    
    //O segundo valor é deixado para as variações das aparições da carta em diferntes jogos (!?!?)
    var secondValue: Int?
}

struct Card
{
    var suit: Suit
    
    var rank: Rank

    var values: Values

    var hidden: Bool
    
    var frontCard: UIImage
    
    var backCard: UIImage

    init(suitOfCard umSuit: Suit, RankOfCard umRank: Rank, HiddenCard umHidden: Bool, FirstValueOfCard umValue: Int, ImageFrontCard umaImageFront: UIImage, ImageBackCard umaImageBack: UIImage)
    {
        self.suit = umSuit
        self.rank = umRank
        self.hidden = umHidden
        self.values = Values(firstValue: umValue, secondValue: nil)
        self.frontCard = umaImageFront
        self.backCard = umaImageBack
    }
    
    var description: String {
        
        if !hidden
        {
            return "\(rank.description()) of \(suit.description())"
        }
        else
        {
            return ""
        }
    }
    
    var rawDescription: String {
        
        if !hidden
        {
            return "\(rank.values())\(suit.rawValue)"
        }
        else
        {
            return ""
        }
        
    }
    
}

