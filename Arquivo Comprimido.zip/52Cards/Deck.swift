//
//  Deck.swift
//  Project 52 Cards
//
//  Created by Caue Scalzaretto on 09/03/16.
//  Copyright © 2016 Caue Scalzaretto. All rights reserved.
//

import Foundation
import UIKit

class Deck
{
    
    // MARK: PROPERTIES
    var cards: [Card] = []
    
    // RANK: METHODS
    func createDeck()
    {
        let theSuits = [Suit.Spades, Suit.Hearts, Suit.Diamonds, Suit.Clubs]
        let theRanks = [Rank.Ace, Rank.Two, Rank.Three, Rank.Four, Rank.Five, Rank.Six, Rank.Seven, Rank.Eight, Rank.Nine, Rank.Ten, Rank.Jack, Rank.Queen, Rank.King]

        cards.removeAll()
        
        for umSuit in theSuits
        {
            for umRank in theRanks
            {
                
                cards.append(Card(suitOfCard: umSuit
                                , RankOfCard: umRank
                                , HiddenCard: true
                                , FirstValueOfCard: umRank.values()
                                , ImageFrontCard: UIImage(named: "\(umRank.description())_of_\(umSuit.description())")!
                                , ImageBackCard: UIImage(named: "cardback")!))

            }
        }
    }
    
    func shuffleCardsInDeck()
    {
        cards.shuffleInPlace()
    }
    
    func drawCard(Hidden hidden: Bool) -> Card
    {
        cards[0].hidden = hidden
        return cards.removeAtIndex(0)
    }
    
}
