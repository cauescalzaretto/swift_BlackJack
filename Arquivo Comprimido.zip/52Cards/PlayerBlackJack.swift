//
//  PlayerBlackJack.swift
//  52Cards
//
//  Created by Caue Scalzaretto on 13/03/16.
//  Copyright © 2016 Caue Scalzaretto. All rights reserved.
//

import Foundation
import UIKit

class PlayerBlackJack: Player, ViewPlayerBlackJackDelegate {
    
    
    //--------------------------
    // MARK: PROPERTIES
    //--------------------------
    
    // Objeto no qual o usuario irá interagir quando estiver jogando
    private var uiViewPlayer: ViewPlayerBlackJack
    
    // Armazena a aposta do jogador
    private var bet: Int = 0
    
    // Calcula automaticamente a pontuacao do jogador a cada nova carta recebida
    private var score: Int{
        get{
        
            var sumValueCards:Int = 0
            var acesQuantity: Int = 0
            
            for umCard in self.displayCardsOfPlayer()
            {
                if umCard.rank.values() == Rank.Ace.values()
                {
                    acesQuantity++
                }
                
                sumValueCards += umCard.rank.values()
            }
            
            //Verifica se o valor do Ás é 1 ou 11
            for (var i=0;i < acesQuantity; i++)
            {
                if((sumValueCards+10) <= 21)
                {
                    sumValueCards+=10
                }
                else
                {
                    break
                }
            }

            return sumValueCards
            
        }
    }
    
    //--------------------------
    // MARK: INIT
    //--------------------------
    
    init(APlayer umPlayer: Player) {

        self.uiViewPlayer = ViewPlayerBlackJack(displayButtons: true)
        self.uiViewPlayer.setTextLabelUp(TextOfLabel: "\(umPlayer.nameOfPlayer())-Cash:\(umPlayer.whereAmountGamingChips())")
        self.uiViewPlayer.setTextLabelBottom(TextOfLabel: "Score: 0 - Bet: 0)")
        
        super.init(NameOfPlayer: umPlayer.nameOfPlayer(), GamingChipsOfPlayer: umPlayer.whereAmountGamingChips())
        
        self.uiViewPlayer.delegate = self

    }

    //--------------------------
    // MARK: EVENTS
    //--------------------------
    
    //Evento disparado ao clicar no botão OPT1, onde
    func clickButtonOption1()
    {
        //Verifica o status do jogador
        switch(self.displayStateOfPlayer())
        {
            
        case .Betting:
            //Done
            self.changeStateOfPlayer(NewStateOfPlayer: stateOfPlayer.Playing)
            break
            
        case .Playing:
            //Hit
            self.addCardToPlayer(ACard: meuBaralho.drawCard(Hidden: false))
            self.uiViewPlayer.displayCardsPlayer(CarsOfPlayer: self.displayCardsOfPlayer())
            self.uiViewPlayer.setTextLabelBottom(TextOfLabel: "Score: \(self.score) - Bet: \(self.returnBetPlayer())")
            //Verifica o score
            self.verifyScore(StatePattern: self.displayStateOfPlayer())
            break
            
        default:
            self.uiViewPlayer.setTextLabelBottom(TextOfLabel: "Score: \(self.score) - \(self.displayStateOfPlayer().description())")
            self.uiViewPlayer.hiddenButtonOption1(IsHidden: true)
            self.uiViewPlayer.hiddenButtonOption2(IsHidden: true)
            break
        }
        
    }
    
    func clickButtonOption2()
    {
        //Verifica o status do jogador
        switch(self.displayStateOfPlayer())
        {
        case .Betting:
            //Increase 10 chips
            increaseBet(ValueBet: 10)
            break
            
        case .Playing:
            //Stand
            self.changeStateOfPlayer(NewStateOfPlayer: stateOfPlayer.Stopping)
            break
            
        default:
            self.uiViewPlayer.setTextLabelBottom(TextOfLabel: "Score: \(self.score) - \(self.displayStateOfPlayer().description())")
            self.uiViewPlayer.hiddenButtonOption1(IsHidden: true)
            self.uiViewPlayer.hiddenButtonOption2(IsHidden: true)
            break
            
        }
        
    }
    
    //-------------------------------
    // MARK: STATE PLAYER FUNCTIONS
    //-------------------------------
    
    //Modifica o status do jogador
    override func changeStateOfPlayer(NewStateOfPlayer umState: stateOfPlayer)
    {
        super.changeStateOfPlayer(NewStateOfPlayer: umState)

        //Verifica o status do jogador para modificar o uiViewPlayer
        switch(self.displayStateOfPlayer())
        {
            
        case .Betting:
            self.uiViewPlayer.setTextLabelBottom(TextOfLabel: "Score: \(self.score) - Bet: \(self.bet)")
            self.uiViewPlayer.setTitleButtonOption1(ButtonTitle: "Done")
            self.uiViewPlayer.hiddenButtonOption1(IsHidden: false)
            self.uiViewPlayer.setTitleButtonOption2(ButtonTitle: "+ 10$")
            self.uiViewPlayer.hiddenButtonOption2(IsHidden: false)
            break
            
        case .Playing:
            self.uiViewPlayer.setTextLabelBottom(TextOfLabel: "Score: \(self.score) - Bet: \(self.bet)")
            self.uiViewPlayer.setTitleButtonOption1(ButtonTitle: "Hit")
            self.uiViewPlayer.hiddenButtonOption1(IsHidden: false)
            self.uiViewPlayer.setTitleButtonOption2(ButtonTitle: "Stand")
            self.uiViewPlayer.hiddenButtonOption2(IsHidden: false)
            break
            
        default:
            self.uiViewPlayer.setTextLabelBottom(TextOfLabel: "Score: \(self.score) - \(self.displayStateOfPlayer().description())")
            self.uiViewPlayer.hiddenButtonOption1(IsHidden: true)
            self.uiViewPlayer.hiddenButtonOption2(IsHidden: true)
            break
        }
    
    }
    
    //-------------------------------
    // MARK: SCORE FUNCTIONS
    //-------------------------------
    
    //Verifica o score e modifica o status do jogador se necessario
    func verifyScore(StatePattern aState: stateOfPlayer)
    {
        if self.displayScore() == 21
        {
            self.changeStateOfPlayer(NewStateOfPlayer: stateOfPlayer.Winning)
        }
        else if self.displayScore() > 21
        {
            self.changeStateOfPlayer(NewStateOfPlayer: stateOfPlayer.Losing)
        }
        else
        {
            self.changeStateOfPlayer(NewStateOfPlayer: aState)
        }
        
    }
    
    // Apresenta o score do jogador
    func displayScore() -> Int
    {
        return score
    }
    
    
    //-------------------------------
    // MARK: VIEW PLAYER FUNCTIONS
    //-------------------------------
    
    func setFrameViewPlayer(Frame aFrame: CGRect)
    {
        self.uiViewPlayer.frame = aFrame
    }
    
    func getViewPlayer() -> ViewPlayerBlackJack
    {
        return self.uiViewPlayer
    }
    
    func displayCardsViewPlayer()
    {
        self.uiViewPlayer.displayCardsPlayer(CarsOfPlayer: self.displayCardsOfPlayer())
    }
    
    
    //-------------------------------
    // MARK: BETTING FUNCTIONS
    //-------------------------------
    
    func returnBetPlayer() -> Int
    {
        return bet
    }
    
    func increaseBet(ValueBet aBet: Int)
    {
        self.bet += aBet
        self.removeGamingChips(QuantityGamingChips: aBet)
        self.uiViewPlayer.setTextLabelUp(TextOfLabel: "\(self.nameOfPlayer())-Cash:\(self.whereAmountGamingChips())")
    }
    
    
    
    
}