//
//  Dealer.swift
//  Project 52 Cards
//
//  Created by Caue Scalzaretto on 09/03/16.
//  Copyright © 2016 Caue Scalzaretto. All rights reserved.
//

import Foundation

class Dealer: Player
{
    
    // MARK: INIT
    
    init()
    {
        super.init(NameOfPlayer: "Dealer Jessica", GamingChipsOfPlayer: 0)
    }
    
    override func addGamingChips(QuantityGamingChips umasChips: Int)
    {
        super.addGamingChips(QuantityGamingChips: 0)
    }
    
    override func removeGamingChips(QuantityGamingChips umasChips: Int)
    {
        super.removeGamingChips(QuantityGamingChips: 0)
    }
    
}