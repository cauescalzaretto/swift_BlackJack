//
//  ViewPlayer.swift
//  52Cards
//
//  Created by Caue Scalzaretto on 02/04/16.
//  Copyright © 2016 Caue Scalzaretto. All rights reserved.
//

import UIKit

//######################################
// MARK: PROTOCOL
//######################################

protocol ViewPlayerBlackJackDelegate
{
    func clickButtonOption1()
    func clickButtonOption2()
    
}


//######################################
// MARK: CLASS
//######################################

class ViewPlayerBlackJack: UIView, ViewPlayerBlackJackDelegate {

    
    //--------------------------
    // MARK: OBJECTS
    //--------------------------
    
    private var labelUpDescriptionPlayer: UILabel!
    private var labelBottomDescriptionPlayer: UILabel!
    private var imageViewCardsPlayer: UIImageView!
    private var buttonOption1Player: UIButton!
    private var buttonOption2Player: UIButton!
    private var imageViewCards = [UIImageView]()
    
    
    // delegate
    var delegate: ViewPlayerBlackJackDelegate?

    //--------------------------
    // MARK: INITIAL METHODS
    //--------------------------
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    init(displayButtons umDisplayButtons: Bool)
    {
        super.init(frame: CGRectMake(0, 0, 85, 132))
        
        self.labelUpDescriptionPlayer = UILabel()
        self.labelUpDescriptionPlayer.frame = CGRectMake(0, 0, 83, 16)
        self.labelUpDescriptionPlayer.text = "labelUpDescriptionPlayer"
        self.labelUpDescriptionPlayer.textAlignment = NSTextAlignment.Center
        self.labelUpDescriptionPlayer.font = UIFont(name: ".SFUIText-Regular", size: 11)
        self.addSubview(labelUpDescriptionPlayer)
        
        self.imageViewCardsPlayer = UIImageView()
        self.imageViewCardsPlayer.frame = CGRectMake(0, 15, 46, 84)
        self.imageViewCardsPlayer.image = UIImage()
        self.addSubview(imageViewCardsPlayer)
        
        self.labelBottomDescriptionPlayer = UILabel()
        self.labelBottomDescriptionPlayer.frame = CGRectMake(0, 98, 83, 16)
        self.labelBottomDescriptionPlayer.text = "labelBottomDescriptionPlayer"
        self.labelBottomDescriptionPlayer.textAlignment = NSTextAlignment.Center
        self.labelBottomDescriptionPlayer.font = UIFont(name: ".SFUIText-Regular", size: 9)
        self.addSubview(labelBottomDescriptionPlayer)
        
        // Apresenta os botões conforme a inicialização
        self.buttonOption1Player = UIButton(type: UIButtonType.System)
        self.buttonOption1Player.frame = CGRectMake(0, 117, 41, 15)
        self.buttonOption1Player.backgroundColor = UIColor.redColor()
        self.buttonOption1Player.tintColor = UIColor.whiteColor()
        self.buttonOption1Player.titleLabel?.font = UIFont(name: ".SFUIText-Regular", size: 10)
        self.buttonOption1Player.setTitle("OPT1", forState: UIControlState.Normal)
        self.buttonOption1Player.addTarget(self, action: Selector("methodClickButtonOption1:"), forControlEvents: UIControlEvents.TouchUpInside)
        self.buttonOption1Player.hidden = !umDisplayButtons
        self.addSubview(buttonOption1Player)

        self.buttonOption2Player = UIButton(type: UIButtonType.System)
        self.buttonOption2Player.frame = CGRectMake(42, 117, 41, 15)
        self.buttonOption2Player.backgroundColor = UIColor.redColor()
        self.buttonOption2Player.tintColor = UIColor.whiteColor()
        self.buttonOption2Player.titleLabel?.font = UIFont(name: ".SFUIText-Regular", size: 10)
        self.buttonOption2Player.setTitle("OPT2", forState: UIControlState.Normal)
        self.buttonOption2Player.addTarget(self, action: Selector("methodClickButtonOption2:"), forControlEvents: UIControlEvents.TouchUpInside)
        self.buttonOption2Player.hidden = !umDisplayButtons
        self.addSubview(buttonOption2Player)
        
        self.delegate = self
        
    }
    
    //--------------------------
    // MARK: EVENTS FUNCTIONS
    //--------------------------
    
    func methodClickButtonOption1(sender: UIButton)
    {
        self.delegate?.clickButtonOption1()
    }

    func methodClickButtonOption2(sender: UIButton)
    {
        self.delegate?.clickButtonOption2()
    }
    
    func clickButtonOption1()
    {
        //TODO
    }
    
    func clickButtonOption2()
    {
        //TODO
    }

    //-----------------------------
    // MARK: LABELS FUNCTIONS
    //-----------------------------
    
    func setTextLabelUp(TextOfLabel umText: String)
    {
        self.labelUpDescriptionPlayer.text = umText
    }
    
    func setTextLabelBottom(TextOfLabel umText: String)
    {
        self.labelBottomDescriptionPlayer.text = umText
    }
    
    
    //-----------------------------
    // MARK: BUTTONS FUNCTIONS
    //-----------------------------
    
    /// Aparece/Desapare o botão da opção 1
    func hiddenButtonOption1(IsHidden isHidden: Bool)
    {
        self.buttonOption1Player.hidden = isHidden
    }

    /// Aparece/Desapare o botão da opção 2
    func hiddenButtonOption2(IsHidden isHidden: Bool)
    {
        self.buttonOption2Player.hidden = isHidden
    }

    /// Modifica o texto do botão da opção 1
    func setTitleButtonOption1(ButtonTitle aTitle: String)
    {
        self.buttonOption1Player.setTitle(aTitle, forState: UIControlState.Normal)
    }

    /// Modifica o texto do botão da opção 2
    func setTitleButtonOption2(ButtonTitle aTitle: String)
    {
        self.buttonOption2Player.setTitle(aTitle, forState: UIControlState.Normal)
    }
    
    //-----------------------------
    // MARK: IMAGE CARDS FUNCTIONS
    //-----------------------------
    
    func displayCardsPlayer(CarsOfPlayer umCards: [Card])
    {
        removeCardsImageView(ImageViewBase: imageViewCardsPlayer)
        
        imageViewCardsPlayer.image = umCards[0].hidden == true ? umCards[0].backCard : umCards[0].frontCard
        
        if umCards.count > 1
        {
            
            for (var index = 1; index <= (umCards.count - 1); index++)
            {
                imageViewCards.append(UIImageView(image: umCards[index].hidden == true ? umCards[index].backCard : umCards[index].frontCard))
                
                self.addSubview(imageViewCards[index - 1])
                
                // Desloca as cartas para a direita
                imageViewCards[index - 1].frame = CGRectMake(imageViewCardsPlayer.frame.minX + CGFloat(10 * index), imageViewCardsPlayer.frame.minY, imageViewCardsPlayer.frame.width, imageViewCardsPlayer.frame.height)
                
            }
        }
    }
    
    private func removeCardsImageView(ImageViewBase umImageView: UIImageView)
    {
        umImageView.image = nil
        
        for img in imageViewCards
        {
            img.removeFromSuperview()
            img.image = nil
        }
        
        imageViewCards = [UIImageView]()
        
    }
    

}


